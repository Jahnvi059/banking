use banking_case
select * from bank